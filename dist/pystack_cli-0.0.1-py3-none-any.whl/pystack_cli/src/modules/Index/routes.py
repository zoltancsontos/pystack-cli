from modules.Index.Index_page import IndexPage

routes = [
    {'url': '/', 'controller': IndexPage()},
]
