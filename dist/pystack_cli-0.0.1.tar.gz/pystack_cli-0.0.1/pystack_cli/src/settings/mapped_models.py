from helpers.general_helpers import *

MAPPED_MODELS = [] + GeneralHelpers.get_models()
